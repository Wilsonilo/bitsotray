//https://github.com/maxogden/menubar

var menubar = require('menubar');

var mb = menubar({
  "icon": "./IconTemplate.png",
  "height": 420
});

//Ready
mb.on('ready', function ready () {

});

//After Window is created
mb.on('after-create-window', function(){
    //mb.window.webContents.openDevTools();

});