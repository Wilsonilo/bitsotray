const {clipboard} = require('electron');
const app = require('electron').remote.app

$(document).ready(function(){

	//Run function Every 3 seconds
	var i = 0;
	function go () {
		askBitso();
	    setTimeout(go, 3000); // callback
	}
	go();

	//Close App 
	$("#closeapp").click(function(){
		app.quit();
	});

});


function copyBitcoinCode(text){
	//https://github.com/electron/electron/blob/master/docs/api/clipboard.md
	clipboard.writeText(text);
}

function askBitso(){
	//Vars
	var urlBitso = "https://api.bitso.com/v3/ticker/";
	var parameters = {

	}

	//Ask for
	$.getJSON(urlBitso, parameters)
        .done(function(data, textStatus, jqXHR) {

           // add new markers to map
           for (var i = 0; i < data["payload"].length; i++)
           {    
                
                var moneda = data["payload"][i]["book"];
                var title = "";

                //Adjust title
                if(moneda == "btc_mxn"){
                	title = "BTC/MXN";
                }else if(moneda == "eth_mxn"){
                	title = "ETH/MXN";
                }else if(moneda == "xrp_btc"){
                	title = "XRP/BTC";
                }else if(moneda == "xrp_mxn"){
                	title = "XRP/MXN";
                }else{
                	title = "ETH/BTC";
                }

                //Adjust Row
                //Title
            	if ($("#" + moneda + " .moneda").html() == ""){
            		$("#" + moneda + " .moneda").html(title);
            	}

            	//Rest
            	//Check for changes

            	//Set prototype for format
            	Number.prototype.format = function(n, x) {
				    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
				    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
				};

				//Check if we are working with MXn or not
				if (moneda == "btc_mxn" || moneda == "eth_mxn" || moneda == "xrp_mxn"){

					//ask
					var actualactual 	= $("#" + moneda + " .actual").html();
	            	var new_actual 		= parseFloat(data["payload"][i]["last"]).format(2, 3);
	            	var new_actual 		= String("$"+new_actual);

	            	if(actualactual != new_actual){
	            		//$("#" + moneda + " .actual").fadeOut().html(new_actual).fadeIn(300);
	            		$("#" + moneda + " .actual").html(new_actual);
	            	}

	            	//High
	            	var actualhigh 		= $("#" + moneda + " .max").html();
	            	var newactualhigh 	= parseFloat(data["payload"][i]["high"]).format(2, 3);
	            	newactualhigh 		= String("$"+newactualhigh);

	            	if(actualhigh != newactualhigh){
	            		//$("#" + moneda + " .max").fadeOut().html(newactualhigh).fadeIn(300);
	            		$("#" + moneda + " .max").html(newactualhigh);
	            	}

	            	//Low
	            	var actuallow 	= $("#" + moneda + " .min").html();
	            	var newactualow = parseFloat(data["payload"][i]["low"]).format(2, 3);
	            	newactualow 	= String("$"+newactualow);

	            	if(actuallow  != newactualow){
	            		//$("#" + moneda + " .min").fadeOut().html(newactualow).fadeIn(300);
	            		$("#" + moneda + " .min").html(newactualow);
	            	}

				} else{

					var actualactual = $("#" + moneda + " .actual").html();
	            	if(actualactual != data["payload"][i]["last"]){
	            		//$("#" + moneda + " .actual").fadeOut().html(data["payload"][i]["last"]).fadeIn(300);
	            		$("#" + moneda + " .actual").html(data["payload"][i]["last"]);
	            	}
	            	var actualhigh = $("#" + moneda + " .max").html();
	            	if(actualhigh != data["payload"][i]["high"]){
	            		//$("#" + moneda + " .max").fadeOut().html(data["payload"][i]["high"]).fadeIn(300);
	            		$("#" + moneda + " .max").html(data["payload"][i]["high"]);
	            	}
	            	var actuallow = $("#" + moneda + " .min").html();
	            	if(actuallow  != data["payload"][i]["low"]){
	            		//$("#" + moneda + " .min").fadeOut().html(data["payload"][i]["low"]).fadeIn(300);
	            		$("#" + moneda + " .min").html(data["payload"][i]["low"]);
	            	}
				}
            	

           }


        })
        .fail(function(jqXHR, textStatus, errorThrown) {

            // log error to browser's console
            console.log(errorThrown.toString());
        });

}